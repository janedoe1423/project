import React from 'react';

const ResourceSupport = () => {
    return (
        <div>
            <h2>Resource Support</h2>
            {/* Add your resource support content here */}
        </div>
    );
};

export default ResourceSupport;