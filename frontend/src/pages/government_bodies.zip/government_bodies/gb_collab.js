import React from "react";

const GbCollab = () => {
    return (
        <div>
            <h1>Collaboration</h1>
        </div>
    );
};

export default GbCollab;