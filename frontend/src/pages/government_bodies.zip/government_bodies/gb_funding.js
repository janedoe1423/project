import React from 'react';

const FundingGrants = () => {
    return (
        <div>
            <h2>Funding</h2>
            {/* Add your funding content here */}
        </div>
    );
};

export default FundingGrants;