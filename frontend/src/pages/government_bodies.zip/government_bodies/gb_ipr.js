import React from 'react';

const IPRFacilitation = () => {
    return (
        <div>
            <h2>IPR</h2>
            {/* Add your IPR content here */}
        </div>
    );
};

export default IPRFacilitation;